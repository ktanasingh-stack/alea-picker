import React from 'react';
import { X, ShieldCheck, Lock, HardDrive, EyeOff, Mail } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-policy-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 id="privacy-policy-title" className="text-base font-bold text-slate-900 dark:text-white font-display">
                Privacy Policy
              </h3>
              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                Last updated: March 2026 · Alea Randomizer
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Privacy Policy dialog"
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="px-6 py-5 overflow-y-auto space-y-5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          {/* Section 1 */}
          <div className="space-y-1.5">
            <h4 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2 text-xs uppercase tracking-wider">
              <EyeOff className="w-4 h-4 text-indigo-500" />
              <span>1. Zero Remote Tracking & Client-Side Execution</span>
            </h4>
            <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
              Alea operates entirely in your local browser sandbox. Every single random draw, exclusion list calculation, and distribution analysis runs client-side using native JavaScript and the W3C Web Cryptography API. We do not transmit, record, or log your numbers or draws to any remote server or database.
            </p>
          </div>

          {/* Section 2 */}
          <div className="space-y-1.5">
            <h4 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2 text-xs uppercase tracking-wider">
              <HardDrive className="w-4 h-4 text-indigo-500" />
              <span>2. Local Storage Usage</span>
            </h4>
            <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
              To provide a seamless experience between browser tabs and visits, the application stores your user preferences locally on your device via standard browser <code className="font-mono text-[11px] bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">localStorage</code>:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-xs text-slate-500 dark:text-slate-400">
              <li>Configured range boundaries (minimum, maximum, batch quantity)</li>
              <li>Exclusion items and rule parameters</li>
              <li>Draw history logs (stored only on your machine)</li>
              <li>Visual theme preference (Dark or Light) and sound mute status</li>
            </ul>
            <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
              This data never leaves your device. You can permanently erase all stored logs and settings at any time using the <em>Clear All</em> or <em>Clear History</em> buttons.
            </p>
          </div>

          {/* Section 3 */}
          <div className="space-y-1.5">
            <h4 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2 text-xs uppercase tracking-wider">
              <Lock className="w-4 h-4 text-indigo-500" />
              <span>3. No Third-Party Cookies or Profiling</span>
            </h4>
            <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
              We do not utilize cross-site tracking cookies, behavioral tracking pixels, or invasive ad profiling networks. All sound effects are generated algorithmically in real-time via the browser’s Web Audio API without downloading external audio files or tracking payloads.
            </p>
          </div>

          {/* Section 4 */}
          <div className="space-y-1.5">
            <h4 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2 text-xs uppercase tracking-wider">
              <Mail className="w-4 h-4 text-indigo-500" />
              <span>4. Contact & Inquiries</span>
            </h4>
            <p className="text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
              If you have any questions or privacy concerns regarding Alea Randomizer, please contact our support team at{' '}
              <a
                href="mailto:quizmk24@gmail.com"
                className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                quizmk24@gmail.com
              </a>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold rounded-xl transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
