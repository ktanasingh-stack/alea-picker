import React, { useState, useEffect } from 'react';
import {
  X,
  Activity,
  Users,
  Eye,
  BarChart2,
  Laptop,
  Smartphone,
  Globe,
  RefreshCw,
  CheckCircle,
  ExternalLink,
  Shield,
  HelpCircle,
} from 'lucide-react';
import { TrafficStats } from '../utils/trafficTracker';

interface LiveTrafficModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: TrafficStats;
  onRefresh: () => void;
  gaId: string;
  onSaveGaId: (id: string) => void;
}

export const LiveTrafficModal: React.FC<LiveTrafficModalProps> = ({
  isOpen,
  onClose,
  stats,
  onRefresh,
  gaId,
  onSaveGaId,
}) => {
  const [inputGa, setInputGa] = useState(gaId);
  const [gaSaved, setGaSaved] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    setInputGa(gaId);
  }, [gaId]);

  if (!isOpen) return null;

  const handleSaveGa = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveGaId(inputGa.trim());
    setGaSaved(true);
    setTimeout(() => setGaSaved(false), 2200);
  };

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await onRefresh();
    setTimeout(() => setIsRefreshing(false), 400);
  };

  const maxHourViews = Math.max(1, ...stats.hourlyDistribution.map((h) => h.views));

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="live-traffic-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Activity className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="live-traffic-title" className="text-base font-bold text-slate-900 dark:text-white font-display">
                  Live Traffic & Visitor Analytics
                </h3>
                <span className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 rounded-full text-[11px] font-mono font-bold text-emerald-700 dark:text-emerald-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping inline-block" />
                  Live Active
                </span>
              </div>
              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                Server-authoritative heartbeat telemetry & live presence monitor
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              title="Refresh telemetry"
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              aria-label="Close Traffic dialog"
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="px-6 py-5 overflow-y-auto space-y-6">
          {/* Key Telemetry Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Live active right now */}
            <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/60 rounded-xl relative overflow-hidden">
              <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 text-xs font-semibold mb-1">
                <span>Active Right Now</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <span className="text-3xl font-bold font-mono text-emerald-700 dark:text-emerald-200 tabular-nums">
                {stats.liveVisitors}
              </span>
              <p className="text-[10px] text-emerald-600/80 dark:text-emerald-400/80 mt-1">
                {stats.liveVisitors === 1 ? '1 active visitor' : `${stats.liveVisitors} concurrent visitors`}
              </p>
            </div>

            {/* Today's Visitors */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
              <span className="block text-xs text-slate-500 dark:text-slate-400 font-medium">
                Today's Visitors
              </span>
              <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
                {stats.todayVisitors.toLocaleString()}
              </span>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                Unique daily sessions
              </p>
            </div>

            {/* Today's Pageviews */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
              <span className="block text-xs text-slate-500 dark:text-slate-400 font-medium">
                Today's Views
              </span>
              <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
                {stats.todayPageviews.toLocaleString()}
              </span>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                Page interactions
              </p>
            </div>

            {/* All-Time Views */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
              <span className="block text-xs text-slate-500 dark:text-slate-400 font-medium">
                Total Views
              </span>
              <span className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
                {stats.totalPageviews.toLocaleString()}
              </span>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                All-time traffic
              </p>
            </div>
          </div>

          {/* Current Active Visitors Detail List */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Live Active Sessions ({stats.currentLiveList.length || 1})</span>
              </h4>
              <span className="text-[11px] text-slate-400 dark:text-slate-500 font-mono">
                Auto-refreshed every 20s
              </span>
            </div>

            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {stats.currentLiveList.length === 0 ? (
                <div className="p-3 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/30">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                      Current Session (You)
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400 text-[11px]">
                    <span>Active just now</span>
                    <span>·</span>
                    <span>Path: /</span>
                  </div>
                </div>
              ) : (
                stats.currentLiveList.map((v, i) => (
                  <div
                    key={v.sessionId + i}
                    className="p-3 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/30 hover:bg-slate-100/60 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                      <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                        Session #{v.sessionId}
                      </span>
                      <span className="text-[11px] text-slate-400 dark:text-slate-500">
                        ({v.device} · {v.browser})
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400 text-[11px]">
                      <span>{v.activeSecondsAgo === 0 ? 'Just now' : `${v.activeSecondsAgo}s ago`}</span>
                      <span>·</span>
                      <span className="font-mono text-indigo-600 dark:text-indigo-400">{v.path}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* 24-Hour Traffic Curve Histogram */}
          {stats.hourlyDistribution.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <BarChart2 className="w-3.5 h-3.5" />
                  <span>24-Hour Activity Trend</span>
                </h4>
                <span className="text-[11px] text-slate-400 dark:text-slate-500">
                  Hourly traffic distribution
                </span>
              </div>
              <div className="h-20 flex items-end gap-1 p-2 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
                {stats.hourlyDistribution.map((h, idx) => {
                  const pct = Math.max(10, Math.round((h.views / maxHourViews) * 100));
                  return (
                    <div
                      key={idx}
                      className="flex-1 flex flex-col items-center group relative h-full justify-end"
                      title={`${h.hour}: ~${h.views} visits`}
                    >
                      <div
                        style={{ height: `${pct}%` }}
                        className="w-full bg-indigo-500/80 group-hover:bg-indigo-400 rounded-t-sm transition-all"
                      />
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-1 px-1">
                <span>00:00</span>
                <span>06:00</span>
                <span>12:00</span>
                <span>18:00</span>
                <span>23:00</span>
              </div>
            </div>
          )}

          {/* External Google Analytics Integration Card */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-0.5">
                <h4 className="text-xs font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Google Analytics 4 (GA4) Integration</span>
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Alea already tracks live visitors via server heartbeat. You can also connect your own Google Analytics property by entering your Measurement ID below.
                </p>
              </div>

              {gaId && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-mono font-medium rounded-md shrink-0">
                  <CheckCircle className="w-3 h-3" />
                  Active: {gaId}
                </span>
              )}
            </div>

            <form onSubmit={handleSaveGa} className="flex gap-2">
              <input
                type="text"
                value={inputGa}
                onChange={(e) => setInputGa(e.target.value)}
                placeholder="G-XXXXXXXXXX"
                className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase"
              />
              <button
                type="submit"
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-colors shrink-0 cursor-pointer"
              >
                {gaSaved ? 'Saved!' : 'Save ID'}
              </button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 shrink-0">
          <div className="flex items-center gap-1.5 text-[11px]">
            <Shield className="w-3.5 h-3.5 text-indigo-500" />
            <span>Privacy-preserving: No personal data or IP addresses are stored.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
