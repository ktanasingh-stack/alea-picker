import React, { useState } from 'react';
import { Ban, Plus, Trash2, SlidersHorizontal, AlertCircle, X } from 'lucide-react';
import { ExclusionItem } from '../types/randomizer';
import { parseExclusionInput } from '../utils/random';

interface ExclusionPanelProps {
  exclusions: ExclusionItem[];
  setExclusions: React.Dispatch<React.SetStateAction<ExclusionItem[]>>;
  rangeMin: number;
  rangeMax: number;
  disabled: boolean;
}

export const ExclusionPanel: React.FC<ExclusionPanelProps> = ({
  exclusions,
  setExclusions,
  rangeMin,
  rangeMax,
  disabled,
}) => {
  const [inputValue, setInputValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleAdd = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim()) return;

    const parsed = parseExclusionInput(inputValue);
    if (parsed.length === 0) {
      setError('Please enter valid numbers or ranges (e.g. 13, 20-25)');
      return;
    }

    setExclusions((prev) => {
      // Deduplicate by label
      const existingLabels = new Set(prev.map((i) => i.label));
      const fresh = parsed.filter((p) => !existingLabels.has(p.label));
      return [...prev, ...fresh];
    });

    setInputValue('');
    setError(null);
  };

  const handleRemove = (id: string) => {
    setExclusions((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearAll = () => {
    setExclusions([]);
    setError(null);
  };

  // Quick exclusion generators
  const excludeEven = () => {
    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    const span = high - low + 1;
    if (span > 500) {
      // For large ranges, add a single batch marker or warn
      setError('Even/Odd presets are best applied to ranges under 500 numbers.');
      return;
    }
    const evens: ExclusionItem[] = [];
    for (let i = low; i <= high; i++) {
      if (i % 2 === 0) {
        evens.push({
          id: `single-${i}-${Date.now()}-${Math.random()}`,
          type: 'single',
          value: i,
          label: `${i}`,
          createdAt: Date.now(),
        });
      }
    }
    setExclusions((prev) => {
      const existing = new Set(prev.map((x) => x.label));
      return [...prev, ...evens.filter((e) => !existing.has(e.label))];
    });
  };

  const excludeOdd = () => {
    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    const span = high - low + 1;
    if (span > 500) {
      setError('Even/Odd presets are best applied to ranges under 500 numbers.');
      return;
    }
    const odds: ExclusionItem[] = [];
    for (let i = low; i <= high; i++) {
      if (Math.abs(i) % 2 === 1) {
        odds.push({
          id: `single-${i}-${Date.now()}-${Math.random()}`,
          type: 'single',
          value: i,
          label: `${i}`,
          createdAt: Date.now(),
        });
      }
    }
    setExclusions((prev) => {
      const existing = new Set(prev.map((x) => x.label));
      return [...prev, ...odds.filter((o) => !existing.has(o.label))];
    });
  };

  const excludeMultiples = (mult: number) => {
    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    const span = high - low + 1;
    if (span > 1000) {
      setError('Multiples preset is best for ranges under 1000 numbers.');
      return;
    }
    const mults: ExclusionItem[] = [];
    for (let i = low; i <= high; i++) {
      if (i % mult === 0) {
        mults.push({
          id: `single-${i}-${Date.now()}-${Math.random()}`,
          type: 'single',
          value: i,
          label: `${i}`,
          createdAt: Date.now(),
        });
      }
    }
    setExclusions((prev) => {
      const existing = new Set(prev.map((x) => x.label));
      return [...prev, ...mults.filter((m) => !existing.has(m.label))];
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Exclusion List
            </h2>
            <span className="text-xs font-mono font-semibold text-amber-600 dark:text-amber-400">
              ({exclusions.length} {exclusions.length === 1 ? 'rule' : 'rules'})
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Specify numbers or ranges that should never be selected
          </p>
        </div>

        {exclusions.length > 0 && (
          <button
            onClick={handleClearAll}
            disabled={disabled}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-rose-600 hover:text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        )}
      </div>

      {/* Input row */}
      <form onSubmit={handleAdd} className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={inputValue}
            disabled={disabled}
            onChange={(e) => {
              setInputValue(e.target.value);
              if (error) setError(null);
            }}
            placeholder="e.g. 13, 27, 40-50, 99"
            className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-950/60 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
          />
        </div>
        <button
          type="submit"
          disabled={disabled || !inputValue.trim()}
          className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white text-xs font-semibold rounded-xl transition-colors disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add</span>
        </button>
      </form>

      {error && (
        <div className="mt-2 flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Preset Action Buttons */}
      <div className="mt-3.5 flex flex-wrap items-center gap-1.5">
        <span className="text-xs text-slate-500 dark:text-slate-400 mr-1">Presets:</span>
        <button
          type="button"
          disabled={disabled}
          onClick={excludeEven}
          className="px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          Exclude Even
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={excludeOdd}
          className="px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          Exclude Odd
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => excludeMultiples(5)}
          className="px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          Exclude Multiples of 5
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => excludeMultiples(10)}
          className="px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
        >
          Exclude Multiples of 10
        </button>
      </div>

      {/* Exclusion tags list */}
      <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        {exclusions.length === 0 ? (
          <p className="text-xs text-slate-500 dark:text-slate-400 italic">
            No numbers are currently excluded. All numbers in the range can be drawn.
          </p>
        ) : (
          <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto pr-1">
            {exclusions.map((item) => (
              <span
                key={item.id}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-lg text-xs font-mono font-medium text-amber-900 dark:text-amber-200"
              >
                <span>{item.label}</span>
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => handleRemove(item.id)}
                  className="text-amber-700 dark:text-amber-400 hover:text-amber-950 dark:hover:text-amber-100 transition-colors"
                  aria-label={`Remove exclusion ${item.label}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
