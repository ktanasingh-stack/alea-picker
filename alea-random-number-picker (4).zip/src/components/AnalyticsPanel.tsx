import React from 'react';
import { HistoryRecord } from '../types/randomizer';
import { BarChart3, TrendingUp, Flame, Snowflake, Hash } from 'lucide-react';

interface AnalyticsPanelProps {
  history: HistoryRecord[];
  rangeMin: number;
  rangeMax: number;
}

export const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({
  history,
  rangeMin,
  rangeMax,
}) => {
  // Aggregate all picked numbers
  const allNumbers: number[] = [];
  history.forEach((h) => allNumbers.push(...h.results));

  if (allNumbers.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center shadow-xs">
        <BarChart3 className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          No Distribution Data Yet
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
          Start rolling or spinning to build frequency statistics, hot/cold analysis, and randomness distribution charts.
        </p>
      </div>
    );
  }

  // Frequency map
  const freqMap: Record<number, number> = {};
  let evenCount = 0;
  let oddCount = 0;
  let sum = 0;
  let min = allNumbers[0];
  let max = allNumbers[0];

  allNumbers.forEach((n) => {
    freqMap[n] = (freqMap[n] || 0) + 1;
    if (Math.abs(n) % 2 === 0) evenCount++;
    else oddCount++;
    sum += n;
    if (n < min) min = n;
    if (n > max) max = n;
  });

  const avg = (sum / allNumbers.length).toFixed(1);
  const evenPct = Math.round((evenCount / allNumbers.length) * 100);
  const oddPct = 100 - evenPct;

  // Sorted frequencies for Hot & Cold
  const sortedEntries = Object.entries(freqMap)
    .map(([numStr, count]) => ({ num: parseInt(numStr, 10), count }))
    .sort((a, b) => b.count - a.count);

  const hotNumbers = sortedEntries.slice(0, 5);
  const coldNumbers = [...sortedEntries].reverse().slice(0, 5);

  // Frequency Histogram buckets or distinct numbers
  const maxFreq = Math.max(...sortedEntries.map((e) => e.count));
  // Display top 12 most frequent numbers in chart
  const chartItems = sortedEntries.slice(0, 12);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-6">
      <div>
        <h2 className="text-base font-semibold text-slate-900 dark:text-white">
          Distribution & Analytics
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Statistical audit of {allNumbers.length} numbers drawn across {history.length} sessions
        </p>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <span className="block text-xs text-slate-500 dark:text-slate-400">Total Draws</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
            {history.length}
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <span className="block text-xs text-slate-500 dark:text-slate-400">Mean Average</span>
          <span className="text-xl font-bold font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
            {avg}
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <span className="block text-xs text-slate-500 dark:text-slate-400">Lowest Picked</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
            {min}
          </span>
        </div>

        <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <span className="block text-xs text-slate-500 dark:text-slate-400">Highest Picked</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
            {max}
          </span>
        </div>
      </div>

      {/* Even vs Odd Parity Ratio */}
      <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-2">
          <span>Even: <strong className="font-mono text-slate-900 dark:text-white">{evenCount} ({evenPct}%)</strong></span>
          <span>Odd: <strong className="font-mono text-slate-900 dark:text-white">{oddCount} ({oddPct}%)</strong></span>
        </div>
        <div className="w-full h-3 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden flex">
          <div
            style={{ width: `${evenPct}%` }}
            className="h-full bg-indigo-500 transition-all duration-500"
            title={`Even: ${evenPct}%`}
          />
          <div
            style={{ width: `${oddPct}%` }}
            className="h-full bg-violet-400 transition-all duration-500"
            title={`Odd: ${oddPct}%`}
          />
        </div>
      </div>

      {/* Hot & Cold Numbers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Hot */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 mb-3">
            <Flame className="w-4 h-4" />
            <span>Hot Numbers (Most Frequent)</span>
          </div>
          <div className="space-y-2">
            {hotNumbers.map(({ num, count }) => (
              <div key={num} className="flex items-center justify-between text-xs">
                <span className="font-mono font-bold text-slate-900 dark:text-white">#{num}</span>
                <span className="text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                  {count} {count === 1 ? 'time' : 'times'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Cold */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-600 dark:text-cyan-400 mb-3">
            <Snowflake className="w-4 h-4" />
            <span>Cold Numbers (Least Frequent)</span>
          </div>
          <div className="space-y-2">
            {coldNumbers.map(({ num, count }) => (
              <div key={num} className="flex items-center justify-between text-xs">
                <span className="font-mono font-bold text-slate-900 dark:text-white">#{num}</span>
                <span className="text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                  {count} {count === 1 ? 'time' : 'times'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Frequency Histogram Chart */}
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
          Frequency Histogram (Top Drawn Numbers)
        </h4>
        <div className="space-y-2">
          {chartItems.map(({ num, count }) => {
            const pct = Math.max(8, Math.round((count / maxFreq) * 100));
            return (
              <div key={num} className="flex items-center gap-3 text-xs">
                <span className="w-10 text-right font-mono font-semibold text-slate-900 dark:text-white tabular-nums">
                  {num}
                </span>
                <div className="flex-1 h-6 bg-slate-100 dark:bg-slate-800/80 rounded-lg overflow-hidden flex items-center p-1">
                  <div
                    style={{ width: `${pct}%` }}
                    className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 rounded-md transition-all duration-300 flex items-center justify-end pr-2"
                  >
                    <span className="text-[10px] font-mono text-white font-bold tabular-nums">
                      {count}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
