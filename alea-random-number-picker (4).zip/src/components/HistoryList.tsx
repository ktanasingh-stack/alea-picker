import React, { useState } from 'react';
import { HistoryRecord } from '../types/randomizer';
import {
  Download,
  Trash2,
  Copy,
  Check,
  Search,
  Ban,
  Clock,
  Sparkles,
  FileSpreadsheet,
} from 'lucide-react';

interface HistoryListProps {
  history: HistoryRecord[];
  onClearHistory: () => void;
  onExcludeNumber?: (num: number) => void;
  onTriggerDraw?: () => void;
}

export const HistoryList: React.FC<HistoryListProps> = ({
  history,
  onClearHistory,
  onExcludeNumber,
  onTriggerDraw,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const handleCopySingle = (record: HistoryRecord) => {
    navigator.clipboard.writeText(record.results.join(', '));
    setCopiedId(record.id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleCopyAll = () => {
    if (history.length === 0) return;
    const text = history
      .map(
        (h) =>
          `[${new Date(h.timestamp).toLocaleTimeString()}] ${h.results.join(', ')} (Range: ${
            h.min
          }–${h.max}, Mode: ${h.mode})`
      )
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 1800);
  };

  const handleExportCSV = () => {
    if (history.length === 0) return;
    const header = 'Timestamp,Results,Count,Min,Max,Mode,ExcludedCount\n';
    const rows = history
      .map((h) => {
        const time = new Date(h.timestamp).toISOString();
        const resultsStr = `"${h.results.join(';')}"`;
        return `${time},${resultsStr},${h.results.length},${h.min},${h.max},${h.mode},${h.excludedCount}`;
      })
      .join('\n');

    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `alea-history-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const filtered = history.filter((record) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.trim().toLowerCase();
    const matchesNumber = record.results.some((n) => String(n).includes(term));
    const matchesRange = `${record.min}-${record.max}`.includes(term);
    return matchesNumber || matchesRange;
  });

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              Draw History
            </h2>
            <span className="text-xs font-mono font-medium text-slate-500 dark:text-slate-400">
              ({history.length} {history.length === 1 ? 'record' : 'records'})
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Full audit log of every random draw and rule parameter
          </p>
        </div>

        {history.length > 0 && (
          <div className="flex items-center gap-2 self-stretch sm:self-auto">
            <button
              onClick={handleCopyAll}
              title="Copy entire history"
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-800 transition-colors"
            >
              {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedAll ? 'Copied' : 'Copy All'}</span>
            </button>

            <button
              onClick={handleExportCSV}
              title="Export as CSV"
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-800 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-500" />
              <span>CSV</span>
            </button>

            <button
              onClick={onClearHistory}
              title="Clear all records"
              className="flex items-center justify-center p-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Search Filter */}
      {history.length > 0 && (
        <div className="relative mb-4">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by number or range..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 dark:bg-slate-950/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      )}

      {/* History Items Container */}
      {filtered.length === 0 ? (
        <div className="py-12 text-center">
          <Clock className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
          <p className="text-sm font-medium text-slate-900 dark:text-white">No draw records yet</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
            Numbers drawn using the digital tumbler or spin wheel will appear here with full timestamps.
          </p>
          {onTriggerDraw && (
            <button
              onClick={onTriggerDraw}
              className="mt-4 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors"
            >
              Take First Draw
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
          {filtered.map((record) => {
            const isSingle = record.results.length === 1;
            const timeStr = new Date(record.timestamp).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            });

            return (
              <div
                key={record.id}
                className="group flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3.5 bg-slate-50 dark:bg-slate-950/40 hover:bg-slate-100 dark:hover:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800/80 rounded-xl transition-colors"
              >
                {/* Result Display */}
                <div className="flex items-center gap-3">
                  {isSingle ? (
                    <div className="w-12 h-12 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-lg font-bold font-mono text-indigo-600 dark:text-indigo-400 shadow-xs tabular-nums">
                      {record.results[0]}
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-1 max-w-xs sm:max-w-md">
                      {record.results.map((n, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md text-xs font-mono font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums"
                        >
                          {n}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Metadata (Zero-pill discipline: unboxed text with dots) */}
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
                      <span className="capitalize">{record.mode === 'wheel' ? 'Spin Wheel' : record.mode === 'batch' ? 'Batch Draw' : 'Digital Roller'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">Range: {record.min}–{record.max}</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5 text-[11px]">
                      <span>{timeStr}</span>
                      {record.excludedCount > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{record.excludedCount} excluded</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 self-end sm:self-center opacity-80 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleCopySingle(record)}
                    title="Copy result"
                    className="p-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-white dark:hover:bg-slate-900 transition-colors"
                  >
                    {copiedId === record.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {onExcludeNumber && isSingle && (
                    <button
                      onClick={() => onExcludeNumber(record.results[0])}
                      title={`Exclude ${record.results[0]} from future draws`}
                      className="p-1.5 text-slate-500 hover:text-amber-500 rounded-lg hover:bg-white dark:hover:bg-slate-900 transition-colors"
                    >
                      <Ban className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
