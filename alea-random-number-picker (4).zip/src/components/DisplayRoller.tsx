import React, { useState, useEffect, useRef } from 'react';
import { Play, Copy, Check, Ban, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundEngine } from '../utils/audio';
import { PoolStats } from '../types/randomizer';

interface DisplayRollerProps {
  onDraw: () => { success: boolean; numbers: number[]; error?: string };
  isRolling: boolean;
  setIsRolling: (rolling: boolean) => void;
  lastResults: number[];
  rangeMin: number;
  rangeMax: number;
  batchCount: number;
  poolStats: PoolStats;
  onExcludeNumber?: (num: number) => void;
}

export const DisplayRoller: React.FC<DisplayRollerProps> = ({
  onDraw,
  isRolling,
  setIsRolling,
  lastResults,
  rangeMin,
  rangeMax,
  batchCount,
  poolStats,
  onExcludeNumber,
}) => {
  // Always initialize with a random number at the beginning
  const [displayNumber, setDisplayNumber] = useState<number | string>(() => {
    if (lastResults.length > 0) return lastResults[0];
    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    return Math.floor(Math.random() * (high - low + 1)) + low;
  });
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Sync display with last results when changed externally
  useEffect(() => {
    if (lastResults.length > 0 && !isRolling) {
      setDisplayNumber(lastResults[0]);
    }
  }, [lastResults, isRolling]);

  const triggerRoll = () => {
    if (isRolling || poolStats.isExhausted) return;
    setErrorMsg(null);

    const result = onDraw();
    if (!result.success || result.numbers.length === 0) {
      setErrorMsg(result.error || 'Unable to draw numbers. Check your exclusions.');
      return;
    }

    const finalTarget = result.numbers[0];
    setIsRolling(true);

    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    const startTime = performance.now();
    const duration = 1800; // 1.8s smooth roll with rich acoustic deceleration
    let lastTickTime = 0;

    // Start authentic mechanical rolling rumble sound
    soundEngine.startRollingSound(duration);

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);

      // Deceleration curve (cubic-bezier ease out)
      const easeOut = 1 - Math.pow(1 - progress, 3);
      // Interval between number changes widens as we slow down
      const currentInterval = 30 + easeOut * 280;

      if (now - lastTickTime >= currentInterval) {
        lastTickTime = now;
        // Generate random flashing digits during roll
        const randomNum = Math.floor(Math.random() * (high - low + 1)) + low;
        setDisplayNumber(randomNum);

        // Sound tick with pitch dropping slightly
        soundEngine.playTick(1.0 - progress * 0.3);
      }

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(tick);
      } else {
        // Finished rolling
        soundEngine.stopRollingSound();
        setDisplayNumber(finalTarget);
        setIsRolling(false);
        soundEngine.playWin();

        // Confetti burst
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.65 },
            colors: ['#6366f1', '#a855f7', '#ec4899', '#3b82f6', '#10b981'],
          });
        } catch {
          // confetti safely ignored
        }
      }
    };

    animationFrameRef.current = requestAnimationFrame(tick);
  };

  useEffect(() => {
    return () => {
      soundEngine.stopRollingSound();
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  const handleCopy = () => {
    if (lastResults.length === 0) return;
    const text = lastResults.join(', ');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col items-center justify-center text-center relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-radial from-indigo-500/5 via-transparent to-transparent pointer-events-none" />

      {/* Mode Kicker */}
      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-6">
        <span>Digital Tumbler</span>
        <span aria-hidden="true">·</span>
        <span>Range {rangeMin} to {rangeMax}</span>
        {batchCount > 1 && (
          <>
            <span aria-hidden="true">·</span>
            <span>Batch of {batchCount}</span>
          </>
        )}
      </div>

      {/* Main Single / Primary Hero Digit Display */}
      <div className="relative my-4 flex items-center justify-center w-full max-w-md min-h-[160px] sm:min-h-[200px]">
        <div
          className={`font-mono tabular-nums font-bold tracking-tight text-slate-900 dark:text-white transition-all select-none ${
            isRolling
              ? 'scale-105 text-indigo-600 dark:text-indigo-400 animate-pulse text-6xl sm:text-7xl md:text-8xl'
              : 'text-7xl sm:text-8xl md:text-9xl'
          }`}
          data-tabular="true"
        >
          {displayNumber}
        </div>
      </div>

      {/* Batch Results Grid (if batchCount > 1 and not rolling) */}
      {batchCount > 1 && lastResults.length > 0 && !isRolling && (
        <div className="w-full mt-2 mb-6 pt-5 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-3 px-1">
            <span>All {lastResults.length} Drawn Numbers:</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy All'}</span>
            </button>
          </div>
          <div className="flex flex-wrap gap-2 justify-center max-h-48 overflow-y-auto p-1">
            {lastResults.map((num, idx) => (
              <div
                key={`${num}-${idx}`}
                className="group relative flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-semibold text-slate-900 dark:text-white transition-colors"
              >
                <span>{num}</span>
                {onExcludeNumber && (
                  <button
                    onClick={() => onExcludeNumber(num)}
                    title={`Exclude ${num} from future draws`}
                    className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-400 hover:text-amber-500 transition-opacity"
                  >
                    <Ban className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {errorMsg && (
        <div className="mt-2 mb-4 text-xs font-medium text-rose-600 dark:text-rose-400 max-w-sm">
          {errorMsg}
        </div>
      )}

      {/* Prominent Start / Roll Button */}
      <div className="mt-4 flex flex-col sm:flex-row items-center gap-3 w-full max-w-xs">
        <button
          onClick={triggerRoll}
          disabled={isRolling || poolStats.isExhausted}
          className="w-full py-3.5 px-6 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-base rounded-2xl shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/35 active:scale-98 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          {isRolling ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Rolling...</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              <span>Start</span>
            </>
          )}
        </button>

        {lastResults.length > 0 && !isRolling && batchCount === 1 && (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleCopy}
              title="Copy number to clipboard"
              className="flex-1 sm:flex-initial p-3 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              <span className="sm:hidden">{copied ? 'Copied' : 'Copy'}</span>
            </button>

            {onExcludeNumber && typeof displayNumber === 'number' && (
              <button
                onClick={() => onExcludeNumber(displayNumber)}
                title="Add to exclusion list"
                className="flex-1 sm:flex-initial p-3 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl transition-colors flex items-center justify-center gap-1.5 text-xs font-medium"
              >
                <Ban className="w-4 h-4 text-amber-500" />
                <span className="sm:hidden">Exclude</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Keyboard Hint */}
      <span className="mt-3 text-[11px] text-slate-400 dark:text-slate-500">
        Press <kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-[10px] font-mono">Space</kbd> or <kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-[10px] font-mono">Enter</kbd> to Start
      </span>
    </div>
  );
};
