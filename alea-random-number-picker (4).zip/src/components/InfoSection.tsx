import React, { useState } from 'react';
import {
  HelpCircle,
  ShieldCheck,
  Cpu,
  BookOpen,
  ChevronDown,
  Sparkles,
  Dice5,
  Sliders,
  History,
} from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const FAQS: FAQItem[] = [
  {
    question: 'Are these numbers truly random and mathematically unbiased?',
    answer:
      'Yes. Alea utilizes cryptographically secure pseudo-random number generation (CSPRNG) via window.crypto.getRandomValues combined with rejection sampling. This completely eliminates modulo bias and guarantees that every eligible number within the specified range has an equal, uniform probability of being chosen.',
  },
  {
    question: 'How does the exclusion list work?',
    answer:
      'The exclusion engine checks both individual numbers (e.g. 13) and numerical ranges (e.g. 20–25). When an exclusion rule is added, the candidate number pool is dynamically recalculated to remove excluded values from both the digital tumbler and the spin wheel.',
  },
  {
    question: 'What is the "Auto-Exclude Drawn Numbers" feature?',
    answer:
      'When enabled, any number selected during a draw is automatically appended to your exclusion list. This is ideal for raffle ticket drawings, classroom student turn-taking, and giveaway contests where winners must not be selected more than once.',
  },
  {
    question: 'Can I export or save my draw history?',
    answer:
      'Yes. All draw outcomes are securely recorded in client-side storage with precise timestamps, range parameters, and exclusions. You can copy individual results, copy the entire log to your clipboard, or export everything to a standard CSV spreadsheet.',
  },
  {
    question: 'What is the difference between Digital Roller and Spin Wheel modes?',
    answer:
      'The Digital Roller simulates high-speed number shuffling with progressive friction deceleration, suitable for single draws or batch generations of up to 50 numbers. The Spin Wheel renders a visual roulette wheel with angular momentum physics and a mechanical ticker needle for games and prize picks.',
  },
];

interface InfoSectionProps {
  onOpenPrivacy?: () => void;
  onOpenContact?: () => void;
}

export const InfoSection: React.FC<InfoSectionProps> = ({
  onOpenPrivacy,
  onOpenContact,
}) => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <section
      aria-labelledby="seo-guide-heading"
      className="mt-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs space-y-8"
    >
      {/* Header Banner */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h2
          id="seo-guide-heading"
          className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white font-display flex items-center gap-2.5"
        >
          <BookOpen className="w-5 h-5 text-indigo-500 shrink-0" />
          <span>About Alea Randomizer & Probability Guide</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-3xl leading-relaxed">
          Comprehensive guide to cryptographic random sampling, probability distributions, custom exclusion rules, and mathematical fairness.
        </p>
      </div>

      {/* Feature Columns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm">
        <div className="space-y-2.5">
          <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
            <Cpu className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Cryptographic Security</span>
          </h3>
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            Alea uses browser-native cryptographic primitives (
            <code className="font-mono text-xs bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-indigo-600 dark:text-indigo-400">
              window.crypto.getRandomValues
            </code>
            ) paired with rejection sampling algorithms. Unlike standard pseudo-random functions, this eliminates modulo bias, ensuring true uniform entropy across any positive or negative range.
          </p>
        </div>

        <div className="space-y-2.5">
          <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Exclusions & Pool Validation</span>
          </h3>
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            Configure custom exclusion rules for individual values or spans (e.g. 5–10, 42). Features rule presets (Even, Odd, Multiples of 5/10), multi-number batch drawing with replacement controls, and auto-exclusion for fair raffles and giveaways.
          </p>
        </div>

        <div className="space-y-2.5">
          <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-indigo-500 shrink-0" />
            <span>Real-World Applications</span>
          </h3>
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            Tailored for educators selecting classroom students, raffle administrators conducting transparent prize giveaways, board gamers rolling tabletop dice (D6, D20, D100), software developers testing boundary inputs, and research sampling trials.
          </p>
        </div>
      </div>

      {/* Educational Walkthrough Cards */}
      <div className="pt-6 border-t border-slate-200 dark:border-slate-800">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-4">
          How to Get the Most from Alea
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <Sliders className="w-3.5 h-3.5 text-indigo-500" />
              <span>1. Set Your Range</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400">
              Type any minimum and maximum values (including negative ranges) or pick from instant presets.
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
              <span>2. Exclude Numbers</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400">
              Add forbidden values or enable Auto-Exclude so picked numbers won’t repeat.
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <Dice5 className="w-3.5 h-3.5 text-indigo-500" />
              <span>3. Start or Spin</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400">
              Hit Start for digital tumbling or switch to the Spin Wheel for visual roulette physics and acoustic rolling sound.
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-950/40 border border-slate-200/80 dark:border-slate-800/80 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <History className="w-3.5 h-3.5 text-emerald-500" />
              <span>4. Audit & Export</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400">
              Inspect time-stamped history logs, view distribution histograms, and export audit trails to CSV.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive FAQ Section */}
      <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            Frequently Asked Questions
          </h3>
          <span className="text-xs text-slate-400 dark:text-slate-500 font-mono">
            {FAQS.length} answers
          </span>
        </div>

        <div className="space-y-2.5">
          {FAQS.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full px-4 py-3 text-left flex items-center justify-between gap-3 bg-slate-50/60 dark:bg-slate-950/30 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180 text-indigo-500' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-4 py-3 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/80">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {(onOpenPrivacy || onOpenContact) && (
          <div className="pt-2 flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
            <span>Have questions or need assistance?</span>
            {onOpenContact && (
              <button
                type="button"
                onClick={onOpenContact}
                className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Contact Support
              </button>
            )}
            {onOpenPrivacy && onOpenContact && <span aria-hidden="true">·</span>}
            {onOpenPrivacy && (
              <button
                type="button"
                onClick={onOpenPrivacy}
                className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Read Privacy Policy
              </button>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
