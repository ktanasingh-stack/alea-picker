import React from 'react';
import { ArrowLeftRight, Settings2, ShieldCheck, Check } from 'lucide-react';
import { RangeSettings, PoolStats } from '../types/randomizer';

interface RangeControlsProps {
  settings: RangeSettings;
  setSettings: React.Dispatch<React.SetStateAction<RangeSettings>>;
  poolStats: PoolStats;
  disabled: boolean;
}

const PRESETS = [
  { label: '1 – 10', min: 1, max: 10 },
  { label: '1 – 50', min: 1, max: 50 },
  { label: '1 – 100', min: 1, max: 100 },
  { label: '1 – 6 (D6)', min: 1, max: 6 },
  { label: '1 – 20 (D20)', min: 1, max: 20 },
  { label: '1 – 1000', min: 1, max: 1000 },
  { label: '-50 – +50', min: -50, max: 50 },
];

export const RangeControls: React.FC<RangeControlsProps> = ({
  settings,
  setSettings,
  poolStats,
  disabled,
}) => {
  const handleSwap = () => {
    setSettings((prev) => ({
      ...prev,
      min: prev.max,
      max: prev.min,
    }));
  };

  const applyPreset = (min: number, max: number) => {
    setSettings((prev) => ({
      ...prev,
      min,
      max,
    }));
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900 dark:text-white">
            Range & Rules
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Configure boundaries, batch size, and sampling parameters
          </p>
        </div>

        <button
          onClick={handleSwap}
          disabled={disabled}
          title="Swap Min and Max"
          className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors disabled:opacity-50"
        >
          <ArrowLeftRight className="w-4 h-4" />
        </button>
      </div>

      {/* Min & Max Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Minimum Number
          </label>
          <div className="relative">
            <input
              type="number"
              value={settings.min}
              disabled={disabled}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setSettings((prev) => ({ ...prev, min: isNaN(val) ? 0 : val }));
              }}
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/60 border border-slate-300 dark:border-slate-700 rounded-xl text-base font-semibold text-slate-900 dark:text-white font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
              placeholder="1"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
            Maximum Number
          </label>
          <div className="relative">
            <input
              type="number"
              value={settings.max}
              disabled={disabled}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setSettings((prev) => ({ ...prev, max: isNaN(val) ? 0 : val }));
              }}
              className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950/60 border border-slate-300 dark:border-slate-700 rounded-xl text-base font-semibold text-slate-900 dark:text-white font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
              placeholder="100"
            />
          </div>
        </div>
      </div>

      {/* Quick Presets */}
      <div className="mt-4">
        <span className="block text-xs text-slate-500 dark:text-slate-400 mb-2">
          Quick Range Presets:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {PRESETS.map((p) => {
            const isActive = settings.min === p.min && settings.max === p.max;
            return (
              <button
                key={p.label}
                disabled={disabled}
                onClick={() => applyPreset(p.min, p.max)}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-indigo-600 text-white font-semibold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                } disabled:opacity-50`}
              >
                {p.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Batch Quantity & Sampling Options */}
      <div className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Quantity to Draw
              </label>
              <span className="text-xs font-mono font-medium text-indigo-600 dark:text-indigo-400 tabular-nums">
                {settings.count} {settings.count === 1 ? 'number' : 'numbers'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={1}
                max={Math.min(50, Math.max(1, poolStats.totalInRange))}
                value={settings.count}
                disabled={disabled}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setSettings((prev) => ({ ...prev, count: Math.max(1, val) }));
                }}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <input
                type="number"
                min={1}
                max={100}
                value={settings.count}
                disabled={disabled}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setSettings((prev) => ({
                    ...prev,
                    count: isNaN(val) ? 1 : Math.max(1, Math.min(100, val)),
                  }));
                }}
                className="w-16 px-2 py-1 bg-slate-50 dark:bg-slate-950/60 border border-slate-300 dark:border-slate-700 rounded-lg text-sm text-center font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Result Sorting
            </label>
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {(['none', 'asc', 'desc'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  disabled={disabled}
                  onClick={() => setSettings((prev) => ({ ...prev, autoSort: mode }))}
                  className={`py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap capitalize ${
                    settings.autoSort === mode
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {mode === 'none' ? 'Draw Order' : mode === 'asc' ? 'Ascending' : 'Descending'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Toggles */}
        <div className="mt-4 pt-3 space-y-2.5">
          <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer select-none">
            <span className="flex items-center gap-2">
              <span>Unique Numbers Only</span>
              <span className="text-slate-400 text-[11px]">(No duplicates in batch)</span>
            </span>
            <input
              type="checkbox"
              checked={!settings.allowDuplicates}
              disabled={disabled}
              onChange={(e) =>
                setSettings((prev) => ({ ...prev, allowDuplicates: !e.target.checked }))
              }
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer select-none">
            <span className="flex items-center gap-2">
              <span>Auto-Exclude Drawn Numbers</span>
              <span className="text-slate-400 text-[11px]">(Cannot be drawn again)</span>
            </span>
            <input
              type="checkbox"
              checked={settings.autoExcludeWinner}
              disabled={disabled}
              onChange={(e) =>
                setSettings((prev) => ({ ...prev, autoExcludeWinner: e.target.checked }))
              }
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer"
            />
          </label>
        </div>
      </div>

      {/* Pool Health & Metadata (Zero-pill discipline: unboxed clean text) */}
      <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-2 flex-wrap">
          <span>Range: <strong className="font-mono text-slate-800 dark:text-slate-200">{settings.min} – {settings.max}</strong></span>
          <span aria-hidden="true">·</span>
          <span>Total: <strong className="font-mono text-slate-800 dark:text-slate-200">{poolStats.totalInRange.toLocaleString()}</strong></span>
          <span aria-hidden="true">·</span>
          <span>Excluded: <strong className="font-mono text-amber-600 dark:text-amber-400">{poolStats.excludedCount.toLocaleString()}</strong></span>
          <span aria-hidden="true">·</span>
          <span>Available: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{poolStats.availableCount.toLocaleString()}</strong></span>
        </div>

        {poolStats.isExhausted && (
          <span className="text-rose-600 dark:text-rose-400 font-medium">
            Pool exhausted! Clear exclusions to draw.
          </span>
        )}
      </div>
    </div>
  );
};
