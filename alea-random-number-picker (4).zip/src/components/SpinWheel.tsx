import React, { useRef, useEffect, useState, useCallback } from 'react';
import { RotateCw, Copy, Check, Ban } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundEngine } from '../utils/audio';
import { getWheelSample } from '../utils/random';
import { ExclusionItem, PoolStats } from '../types/randomizer';

interface SpinWheelProps {
  onDraw: () => { success: boolean; numbers: number[]; error?: string };
  isSpinning: boolean;
  setIsSpinning: (spinning: boolean) => void;
  rangeMin: number;
  rangeMax: number;
  exclusions: ExclusionItem[];
  poolStats: PoolStats;
  onExcludeNumber?: (num: number) => void;
  lastResults: number[];
}

const PALETTE = [
  '#6366f1', // Indigo
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#06b6d4', // Cyan
  '#3b82f6', // Blue
  '#f43f5e', // Rose
  '#84cc16', // Lime
];

export const SpinWheel: React.FC<SpinWheelProps> = ({
  onDraw,
  isSpinning,
  setIsSpinning,
  rangeMin,
  rangeMax,
  exclusions,
  poolStats,
  onExcludeNumber,
  lastResults,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [wheelSegments, setWheelSegments] = useState<number[]>([]);
  const [winner, setWinner] = useState<number | null>(() => {
    if (lastResults.length > 0) return lastResults[0];
    const low = Math.min(rangeMin, rangeMax);
    const high = Math.max(rangeMin, rangeMax);
    return Math.floor(Math.random() * (high - low + 1)) + low;
  });
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Wheel physics state
  const rotationRef = useRef<number>(0); // Current angle in radians
  const needleAngleRef = useRef<number>(0); // Needle deflection for mechanical ticker
  const animIdRef = useRef<number | null>(null);
  const lastPegPassedRef = useRef<number>(-1);

  // Refresh segments when range or exclusions change
  useEffect(() => {
    const sample = getWheelSample(rangeMin, rangeMax, exclusions, 24);
    setWheelSegments(sample);
  }, [rangeMin, rangeMax, exclusions]);

  // Draw the wheel onto the canvas
  const drawWheel = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) - 24;

    ctx.clearRect(0, 0, width, height);

    const segments = wheelSegments.length > 0 ? wheelSegments : [1, 2, 3, 4, 5, 6, 7, 8];
    const totalSlices = segments.length;
    const arc = (2 * Math.PI) / totalSlices;

    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(rotationRef.current);

    // Outer shadow rim
    ctx.beginPath();
    ctx.arc(0, 0, radius + 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();

    // Slices
    for (let i = 0; i < totalSlices; i++) {
      const angle = i * arc;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, angle, angle + arc);
      ctx.closePath();

      // Alternating slice colors
      ctx.fillStyle = PALETTE[i % PALETTE.length];
      ctx.fill();

      // Slice border line
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.stroke();

      // Label text
      ctx.save();
      ctx.rotate(angle + arc / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = totalSlices > 18 ? 'bold 12px "JetBrains Mono"' : 'bold 15px "JetBrains Mono"';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
      ctx.shadowBlur = 3;
      ctx.fillText(String(segments[i]), radius - 18, 5);
      ctx.restore();

      // Outer rim pegs
      const pegX = (radius + 2) * Math.cos(angle);
      const pegY = (radius + 2) * Math.sin(angle);
      ctx.beginPath();
      ctx.arc(pegX, pegY, 3, 0, 2 * Math.PI);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    }

    ctx.restore();

    // Center decorative Hub
    ctx.beginPath();
    ctx.arc(centerX, centerY, 38, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(centerX, centerY, 28, 0, 2 * Math.PI);
    ctx.fillStyle = '#1e293b';
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px "Outfit", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('SPIN', centerX, centerY);

    // Ticker / Pointer at top center (pointing down into wheel)
    ctx.save();
    ctx.translate(centerX, centerY - radius + 10);
    ctx.rotate(needleAngleRef.current);

    ctx.beginPath();
    ctx.moveTo(0, 18); // pointer tip
    ctx.lineTo(-12, -14);
    ctx.lineTo(12, -14);
    ctx.closePath();
    ctx.fillStyle = '#ef4444';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
    ctx.shadowBlur = 4;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();

    ctx.restore();
  }, [wheelSegments]);

  useEffect(() => {
    drawWheel();
  }, [drawWheel]);

  // Execute wheel spin
  const triggerSpin = () => {
    if (isSpinning || poolStats.isExhausted) return;
    setErrorMsg(null);

    const result = onDraw();
    if (!result.success || result.numbers.length === 0) {
      setErrorMsg(result.error || 'Cannot spin: no numbers available in current range.');
      return;
    }

    const chosenWinner = result.numbers[0];

    // Ensure chosen winner is in the active segments slice
    let activeSegments = [...wheelSegments];
    let targetIndex = activeSegments.indexOf(chosenWinner);
    if (targetIndex === -1) {
      // Insert chosen winner into segments
      activeSegments = [chosenWinner, ...activeSegments.slice(0, 23)];
      setWheelSegments(activeSegments);
      targetIndex = 0;
    }

    setIsSpinning(true);

    const totalSlices = activeSegments.length;
    const arc = (2 * Math.PI) / totalSlices;

    // Calculate final target rotation:
    // The pointer sits at top (-pi/2 relative to center).
    // Target slice angle centered at pointer:
    // angle = -pi/2 - (targetIndex * arc + arc / 2)
    const targetSliceAngle = -Math.PI / 2 - (targetIndex * arc + arc / 2);

    // Add 6 to 9 full revolutions for dramatic suspense
    const minRevolutions = 6 + Math.random() * 2;
    const currentAngle = rotationRef.current % (2 * Math.PI);
    let delta = targetSliceAngle - currentAngle;
    while (delta < 0) {
      delta += 2 * Math.PI;
    }
    const totalRotationTarget = rotationRef.current + minRevolutions * 2 * Math.PI + delta;

    const startAngle = rotationRef.current;
    const spinDuration = 3800; // 3.8s physics deceleration
    const startTime = performance.now();

    // Start authentic mechanical rolling rumble sound
    soundEngine.startRollingSound(spinDuration);

    const animateSpin = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / spinDuration);

      // Smooth custom ease-out quintic
      const easeOut = 1 - Math.pow(1 - progress, 4);
      const angle = startAngle + (totalRotationTarget - startAngle) * easeOut;
      rotationRef.current = angle;

      // Check peg crossing under pointer for ticker sound & needle deflection
      const currentNorm = ((-angle - Math.PI / 2) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
      const currentPeg = Math.floor(currentNorm / arc);

      if (currentPeg !== lastPegPassedRef.current) {
        lastPegPassedRef.current = currentPeg;
        soundEngine.playTick(1.0 - progress * 0.4);
        needleAngleRef.current = 0.28 * (1 - progress); // needle flick
      } else {
        needleAngleRef.current *= 0.85; // needle returns to center
      }

      drawWheel();

      if (progress < 1) {
        animIdRef.current = requestAnimationFrame(animateSpin);
      } else {
        // Complete
        soundEngine.stopRollingSound();
        needleAngleRef.current = 0;
        drawWheel();
        setIsSpinning(false);
        setWinner(chosenWinner);
        soundEngine.playWin();

        try {
          confetti({
            particleCount: 65,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#6366f1', '#ec4899', '#f59e0b', '#10b981'],
          });
        } catch {
          // confetti safely caught
        }
      }
    };

    animIdRef.current = requestAnimationFrame(animateSpin);
  };

  useEffect(() => {
    return () => {
      soundEngine.stopRollingSound();
      if (animIdRef.current) {
        cancelAnimationFrame(animIdRef.current);
      }
    };
  }, []);

  const handleCopy = () => {
    if (winner === null) return;
    navigator.clipboard.writeText(String(winner));
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col items-center justify-center text-center relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-radial from-violet-500/5 via-transparent to-transparent pointer-events-none" />

      {/* Wheel Header Info */}
      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-4">
        <span>Roulette Wheel</span>
        <span aria-hidden="true">·</span>
        <span>{wheelSegments.length} Segments displayed</span>
        <span aria-hidden="true">·</span>
        <span>Range {rangeMin} to {rangeMax}</span>
      </div>

      {/* Interactive Wheel Canvas */}
      <div className="relative my-2 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={360}
          height={360}
          onClick={triggerSpin}
          className={`cursor-pointer max-w-full drop-shadow-md select-none transition-transform ${
            isSpinning ? 'pointer-events-none' : 'hover:scale-[1.01]'
          }`}
          style={{ width: '340px', height: '340px' }}
        />
      </div>

      {/* Winner Display Badge */}
      {winner !== null && !isSpinning && (
        <div className="mt-3 flex items-center gap-3 px-4 py-2 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl text-indigo-950 dark:text-indigo-200">
          <span className="text-xs font-medium">Selected:</span>
          <span className="text-xl font-bold font-mono tabular-nums">{winner}</span>
          <button
            onClick={handleCopy}
            className="p-1 hover:text-indigo-600 dark:hover:text-white transition-colors"
            title="Copy winner"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
          </button>
          {onExcludeNumber && (
            <button
              onClick={() => onExcludeNumber(winner)}
              className="p-1 hover:text-amber-500 transition-colors"
              title="Exclude from future draws"
            >
              <Ban className="w-4 h-4 text-amber-600" />
            </button>
          )}
        </div>
      )}

      {errorMsg && (
        <div className="mt-2 text-xs font-medium text-rose-600 dark:text-rose-400 max-w-sm">
          {errorMsg}
        </div>
      )}

      {/* Prominent Spin Button */}
      <div className="mt-5 w-full max-w-xs">
        <button
          onClick={triggerSpin}
          disabled={isSpinning || poolStats.isExhausted}
          className="w-full py-3.5 px-6 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-base rounded-2xl shadow-lg shadow-violet-500/25 hover:shadow-violet-500/35 active:scale-98 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <RotateCw className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
          <span>{isSpinning ? 'Spinning...' : 'Spin'}</span>
        </button>
      </div>

      <span className="mt-3 text-[11px] text-slate-400 dark:text-slate-500">
        Click the wheel or press <kbd className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-[10px] font-mono">S</kbd> to Spin
      </span>
    </div>
  );
};
