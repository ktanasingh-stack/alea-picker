export type DrawMode = 'roller' | 'wheel' | 'batch';

export interface RangeSettings {
  min: number;
  max: number;
  count: number;
  allowDuplicates: boolean;
  autoSort: 'none' | 'asc' | 'desc';
  autoExcludeWinner: boolean;
}

export interface ExclusionItem {
  id: string;
  type: 'single' | 'range';
  value?: number;
  start?: number;
  end?: number;
  label: string;
  createdAt: number;
}

export interface HistoryRecord {
  id: string;
  timestamp: number;
  results: number[];
  min: number;
  max: number;
  mode: DrawMode;
  excludedCount: number;
  durationMs?: number;
}

export interface PoolStats {
  totalInRange: number;
  excludedCount: number;
  availableCount: number;
  isExhausted: boolean;
}
