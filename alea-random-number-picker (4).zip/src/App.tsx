import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Header } from './components/Header';
import { RangeControls } from './components/RangeControls';
import { ExclusionPanel } from './components/ExclusionPanel';
import { DisplayRoller } from './components/DisplayRoller';
import { SpinWheel } from './components/SpinWheel';
import { HistoryList } from './components/HistoryList';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { PrivacyModal } from './components/PrivacyModal';
import { ContactModal } from './components/ContactModal';
import { LiveTrafficModal } from './components/LiveTrafficModal';
import { InfoSection } from './components/InfoSection';
import { soundEngine } from './utils/audio';
import { drawRandomNumbers, calculatePoolStats, getCryptoRandomInt } from './utils/random';
import { useTrafficTracker, trackDrawEvent } from './utils/trafficTracker';
import { RangeSettings, ExclusionItem, HistoryRecord } from './types/randomizer';
import { Dices, RotateCw, History, BarChart3, Sparkles } from 'lucide-react';

const DEFAULT_SETTINGS: RangeSettings = {
  min: 1,
  max: 100,
  count: 1,
  allowDuplicates: false,
  autoSort: 'none',
  autoExcludeWinner: false,
};

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('alea_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Sound state
  const [isMuted, setIsMuted] = useState<boolean>(() => soundEngine.getMuted());

  // Range and Rules settings
  const [settings, setSettings] = useState<RangeSettings>(() => {
    try {
      const saved = localStorage.getItem('alea_range_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  // Exclusions state
  const [exclusions, setExclusions] = useState<ExclusionItem[]>(() => {
    try {
      const saved = localStorage.getItem('alea_exclusions');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // Draw History state
  const [history, setHistory] = useState<HistoryRecord[]>(() => {
    try {
      const saved = localStorage.getItem('alea_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // App Navigation & Active View
  const [activeTab, setActiveTab] = useState<'generator' | 'wheel' | 'history' | 'analytics'>('generator');
  const [isRolling, setIsRolling] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);

  // Always have a random number at the beginning
  const [lastResults, setLastResults] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('alea_last_results');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    // Initial random number in range
    return [getCryptoRandomInt(1, 100)];
  });
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isTrafficOpen, setIsTrafficOpen] = useState(false);

  // Live traffic & visitor presence tracker
  const { stats: trafficStats, gaId, saveGaId, fetchFullStats } = useTrafficTracker();

  // Sync dark class on document element
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('alea_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('alea_theme', 'light');
    }
  }, [isDark]);

  // Persist settings
  useEffect(() => {
    localStorage.setItem('alea_range_settings', JSON.stringify(settings));
  }, [settings]);

  // Persist exclusions
  useEffect(() => {
    localStorage.setItem('alea_exclusions', JSON.stringify(exclusions));
  }, [exclusions]);

  // Persist history
  useEffect(() => {
    localStorage.setItem('alea_history', JSON.stringify(history));
  }, [history]);

  // Persist lastResults
  useEffect(() => {
    if (lastResults.length > 0) {
      localStorage.setItem('alea_last_results', JSON.stringify(lastResults));
    }
  }, [lastResults]);

  // Ensure displayed initial number remains valid within active range boundaries
  useEffect(() => {
    if (lastResults.length > 0) {
      const current = lastResults[0];
      const low = Math.min(settings.min, settings.max);
      const high = Math.max(settings.min, settings.max);
      if (current < low || current > high) {
        const nextVal = getCryptoRandomInt(low, high);
        setLastResults([nextVal]);
      }
    }
  }, [settings.min, settings.max, lastResults]);

  // Calculate live pool statistics
  const poolStats = useMemo(() => {
    return calculatePoolStats(settings.min, settings.max, exclusions);
  }, [settings.min, settings.max, exclusions]);

  // Toggle sound
  const handleToggleMute = () => {
    const next = soundEngine.toggleMute();
    setIsMuted(next);
  };

  // Add individual number to exclusions list
  const handleExcludeNumber = useCallback((num: number) => {
    setExclusions((prev) => {
      if (prev.some((item) => item.label === String(num))) return prev;
      return [
        ...prev,
        {
          id: `single-${num}-${Date.now()}`,
          type: 'single',
          value: num,
          label: `${num}`,
          createdAt: Date.now(),
        },
      ];
    });
  }, []);

  // Primary draw computation function
  const performDraw = useCallback(
    (mode: 'roller' | 'wheel' | 'batch') => {
      const drawCount = mode === 'wheel' ? 1 : settings.count;
      const res = drawRandomNumbers(
        settings.min,
        settings.max,
        drawCount,
        settings.allowDuplicates,
        exclusions,
        settings.autoSort
      );

      if (res.success && res.numbers.length > 0) {
        setLastResults(res.numbers);

        // Record in history
        const newRecord: HistoryRecord = {
          id: `hist-${Date.now()}-${Math.random()}`,
          timestamp: Date.now(),
          results: res.numbers,
          min: Math.min(settings.min, settings.max),
          max: Math.max(settings.min, settings.max),
          mode: mode === 'wheel' ? 'wheel' : drawCount > 1 ? 'batch' : 'roller',
          excludedCount: exclusions.length,
        };

        setHistory((prev) => [newRecord, ...prev]);

        // Auto-exclude winner if configured
        if (settings.autoExcludeWinner) {
          res.numbers.forEach((val) => {
            handleExcludeNumber(val);
          });
        }

        // Telemetry draw event
        trackDrawEvent(mode);
      }

      return res;
    },
    [settings, exclusions, handleExcludeNumber]
  );

  // Quick Roll from header
  const handleQuickRoll = () => {
    if (activeTab === 'wheel') {
      performDraw('wheel');
    } else {
      performDraw('roller');
    }
  };

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (e.key === ' ' || e.key === 'Enter') {
        if (!isRolling && !isSpinning) {
          e.preventDefault();
          if (activeTab === 'wheel') {
            performDraw('wheel');
          } else {
            performDraw('roller');
          }
        }
      } else if (e.key === 's' || e.key === 'S') {
        if (!isRolling && !isSpinning) {
          e.preventDefault();
          setActiveTab('wheel');
          performDraw('wheel');
        }
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        handleToggleMute();
      } else if (e.key === '1') {
        setActiveTab('generator');
      } else if (e.key === '2') {
        setActiveTab('wheel');
      } else if (e.key === '3') {
        setActiveTab('history');
      } else if (e.key === '4') {
        setActiveTab('analytics');
      } else if (e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        fetchFullStats();
        setIsTrafficOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        setIsShortcutsOpen(false);
        setIsPrivacyOpen(false);
        setIsContactOpen(false);
        setIsTrafficOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isRolling, isSpinning, activeTab, performDraw]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-indigo-500 selection:text-white">
      {/* 3-Zone Clean Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDark={isDark}
        setIsDark={setIsDark}
        isMuted={isMuted}
        toggleMute={handleToggleMute}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onQuickRoll={handleQuickRoll}
        isRolling={isRolling || isSpinning}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Navigation Selector Bar (Subtle Segmented Switcher for View Modes) */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-1.5 p-1 bg-slate-200/60 dark:bg-slate-900/80 rounded-xl">
            <button
              onClick={() => setActiveTab('generator')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'generator'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Dices className="w-3.5 h-3.5" />
              <span>Digital Roller</span>
            </button>

            <button
              onClick={() => setActiveTab('wheel')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'wheel'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Spin Wheel</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'history'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Draw History ({history.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'analytics'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Analytics</span>
            </button>
          </div>

          {/* Quick status kicker (Zero-pill discipline: unboxed text with dots) */}
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <span>Range: {settings.min} to {settings.max}</span>
            <span aria-hidden="true">·</span>
            <span>{poolStats.availableCount} available</span>
            {exclusions.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-amber-600 dark:text-amber-400 font-medium">
                  {exclusions.length} excluded
                </span>
              </>
            )}
          </div>
        </div>

        {/* View Routing */}
        {activeTab === 'generator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Primary Hero Section: Digital Roller Display */}
            <div className="lg:col-span-7">
              <DisplayRoller
                onDraw={() => performDraw('roller')}
                isRolling={isRolling}
                setIsRolling={setIsRolling}
                lastResults={lastResults}
                rangeMin={settings.min}
                rangeMax={settings.max}
                batchCount={settings.count}
                poolStats={poolStats}
                onExcludeNumber={handleExcludeNumber}
              />
            </div>

            {/* Right Control Panels: Range & Exclusions */}
            <div className="lg:col-span-5 space-y-6">
              <RangeControls
                settings={settings}
                setSettings={setSettings}
                poolStats={poolStats}
                disabled={isRolling || isSpinning}
              />

              <ExclusionPanel
                exclusions={exclusions}
                setExclusions={setExclusions}
                rangeMin={settings.min}
                rangeMax={settings.max}
                disabled={isRolling || isSpinning}
              />
            </div>
          </div>
        )}

        {activeTab === 'wheel' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Primary Hero Section: Spin Wheel */}
            <div className="lg:col-span-7">
              <SpinWheel
                onDraw={() => performDraw('wheel')}
                isSpinning={isSpinning}
                setIsSpinning={setIsSpinning}
                rangeMin={settings.min}
                rangeMax={settings.max}
                exclusions={exclusions}
                poolStats={poolStats}
                onExcludeNumber={handleExcludeNumber}
                lastResults={lastResults}
              />
            </div>

            {/* Right Control Panels */}
            <div className="lg:col-span-5 space-y-6">
              <RangeControls
                settings={settings}
                setSettings={setSettings}
                poolStats={poolStats}
                disabled={isRolling || isSpinning}
              />

              <ExclusionPanel
                exclusions={exclusions}
                setExclusions={setExclusions}
                rangeMin={settings.min}
                rangeMax={settings.max}
                disabled={isRolling || isSpinning}
              />
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-8">
              <HistoryList
                history={history}
                onClearHistory={() => setHistory([])}
                onExcludeNumber={handleExcludeNumber}
                onTriggerDraw={() => {
                  setActiveTab('generator');
                  performDraw('roller');
                }}
              />
            </div>

            <div className="lg:col-span-4 space-y-6">
              <ExclusionPanel
                exclusions={exclusions}
                setExclusions={setExclusions}
                rangeMin={settings.min}
                rangeMax={settings.max}
                disabled={isRolling || isSpinning}
              />
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-8">
              <AnalyticsPanel
                history={history}
                rangeMin={settings.min}
                rangeMax={settings.max}
              />
            </div>

            <div className="lg:col-span-4 space-y-6">
              <HistoryList
                history={history.slice(0, 5)}
                onClearHistory={() => setHistory([])}
                onExcludeNumber={handleExcludeNumber}
              />
            </div>
          </div>
        )}

        {/* SEO & Educational Probability Guide Section */}
        <InfoSection
          onOpenPrivacy={() => setIsPrivacyOpen(true)}
          onOpenContact={() => setIsContactOpen(true)}
        />
      </main>

      {/* Footer (Zero-pill discipline, minimal & clean) */}
      <footer className="w-full border-t border-slate-200 dark:border-slate-800 py-6 mt-12 bg-white/60 dark:bg-slate-950/60 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900 dark:text-white">Alea Randomizer</span>
            <span aria-hidden="true">·</span>
            <span>Cryptographically uniform pseudo-random number generator</span>
          </div>

          <div className="flex flex-wrap items-center gap-x-3.5 gap-y-1.5">
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsContactOpen(true)}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Contact & Support
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsShortcutsOpen(true)}
              className="hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Shortcuts
            </button>
            <span aria-hidden="true">·</span>
            <span>100% Client-Side CSPRNG</span>

            {/* Admin-only trigger (visible only if ?admin is in URL, or via Shift+A shortcut) */}
            {typeof window !== 'undefined' && window.location.search.includes('admin') && (
              <>
                <span aria-hidden="true">·</span>
                <button
                  onClick={() => {
                    fetchFullStats();
                    setIsTrafficOpen(true);
                  }}
                  className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-mono text-[11px] hover:underline cursor-pointer"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Admin ({trafficStats.liveVisitors} live)</span>
                </button>
              </>
            )}
          </div>
        </div>
      </footer>

      {/* Keyboard Shortcuts Modal */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      {/* Privacy Policy Modal */}
      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />

      {/* Contact & Support Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      {/* Live Traffic & Visitor Analytics Modal */}
      <LiveTrafficModal
        isOpen={isTrafficOpen}
        onClose={() => setIsTrafficOpen(false)}
        stats={trafficStats}
        onRefresh={fetchFullStats}
        gaId={gaId}
        onSaveGaId={saveGaId}
      />
    </div>
  );
}
