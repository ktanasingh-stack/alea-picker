import { ExclusionItem, PoolStats } from '../types/randomizer';

/**
 * Cryptographically strong random integer generator within [min, max] inclusive.
 */
export function getCryptoRandomInt(min: number, max: number): number {
  if (min > max) {
    const temp = min;
    min = max;
    max = temp;
  }
  const range = max - min + 1;
  if (range <= 1) return min;

  // Rejection sampling for uniform distribution without modulo bias
  const maxUint32 = 0xffffffff;
  const limit = maxUint32 - (maxUint32 % range);
  const buffer = new Uint32Array(1);

  let rand: number;
  do {
    window.crypto.getRandomValues(buffer);
    rand = buffer[0];
  } while (rand >= limit);

  return min + (rand % range);
}

/**
 * Checks if a specific number is blocked by any exclusion item
 */
export function isNumberExcluded(num: number, exclusions: ExclusionItem[]): boolean {
  for (const item of exclusions) {
    if (item.type === 'single' && item.value === num) {
      return true;
    }
    if (item.type === 'range' && item.start !== undefined && item.end !== undefined) {
      const low = Math.min(item.start, item.end);
      const high = Math.max(item.start, item.end);
      if (num >= low && num <= high) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Normalizes exclusion set and calculates pool statistics for [min, max]
 */
export function calculatePoolStats(min: number, max: number, exclusions: ExclusionItem[]): PoolStats {
  const low = Math.min(min, max);
  const high = Math.max(min, max);
  const totalInRange = high - low + 1;

  if (totalInRange <= 0) {
    return {
      totalInRange: 0,
      excludedCount: 0,
      availableCount: 0,
      isExhausted: true,
    };
  }

  // Count overlaps between exclusions and [low, high]
  let excludedCount = 0;

  if (totalInRange <= 500000) {
    // Exact set-based counting
    const excludedSet = new Set<number>();
    for (const item of exclusions) {
      if (item.type === 'single' && item.value !== undefined) {
        if (item.value >= low && item.value <= high) {
          excludedSet.add(item.value);
        }
      } else if (item.type === 'range' && item.start !== undefined && item.end !== undefined) {
        const rLow = Math.max(low, Math.min(item.start, item.end));
        const rHigh = Math.min(high, Math.max(item.start, item.end));
        for (let i = rLow; i <= rHigh; i++) {
          excludedSet.add(i);
        }
      }
    }
    excludedCount = excludedSet.size;
  } else {
    // For large ranges, merge disjoint intervals
    const intervals: [number, number][] = [];
    for (const item of exclusions) {
      if (item.type === 'single' && item.value !== undefined) {
        if (item.value >= low && item.value <= high) {
          intervals.push([item.value, item.value]);
        }
      } else if (item.type === 'range' && item.start !== undefined && item.end !== undefined) {
        const rLow = Math.max(low, Math.min(item.start, item.end));
        const rHigh = Math.min(high, Math.max(item.start, item.end));
        if (rLow <= rHigh) {
          intervals.push([rLow, rHigh]);
        }
      }
    }

    intervals.sort((a, b) => a[0] - b[0]);
    const merged: [number, number][] = [];
    for (const interval of intervals) {
      if (merged.length === 0) {
        merged.push(interval);
      } else {
        const prev = merged[merged.length - 1];
        if (interval[0] <= prev[1] + 1) {
          prev[1] = Math.max(prev[1], interval[1]);
        } else {
          merged.push(interval);
        }
      }
    }

    excludedCount = merged.reduce((acc, [s, e]) => acc + (e - s + 1), 0);
  }

  const availableCount = Math.max(0, totalInRange - excludedCount);
  return {
    totalInRange,
    excludedCount,
    availableCount,
    isExhausted: availableCount === 0,
  };
}

/**
 * Gets a sample of available numbers for the spin wheel (up to 32 slices for display)
 */
export function getWheelSample(min: number, max: number, exclusions: ExclusionItem[], sampleLimit = 24): number[] {
  const low = Math.min(min, max);
  const high = Math.max(min, max);
  const total = high - low + 1;

  if (total <= 0) return [];

  // If pool is reasonably sized, collect all available
  if (total <= 300) {
    const available: number[] = [];
    for (let i = low; i <= high; i++) {
      if (!isNumberExcluded(i, exclusions)) {
        available.push(i);
      }
    }
    if (available.length <= sampleLimit) {
      return available;
    }
    // Take an evenly distributed slice
    const step = available.length / sampleLimit;
    const sampled: number[] = [];
    for (let i = 0; i < sampleLimit; i++) {
      sampled.push(available[Math.floor(i * step)]);
    }
    return sampled;
  }

  // Large range: gather up to sampleLimit valid distinct numbers
  const sampled = new Set<number>();
  let attempts = 0;
  while (sampled.size < sampleLimit && attempts < 500) {
    attempts++;
    const cand = getCryptoRandomInt(low, high);
    if (!isNumberExcluded(cand, exclusions)) {
      sampled.add(cand);
    }
  }
  return Array.from(sampled).sort((a, b) => a - b);
}

/**
 * Draws random numbers respecting range, exclusions, quantity, and replacement rules
 */
export function drawRandomNumbers(
  min: number,
  max: number,
  count: number,
  allowDuplicates: boolean,
  exclusions: ExclusionItem[],
  autoSort: 'none' | 'asc' | 'desc' = 'none'
): { success: boolean; numbers: number[]; error?: string } {
  const low = Math.min(min, max);
  const high = Math.max(min, max);
  const totalInRange = high - low + 1;

  const stats = calculatePoolStats(low, high, exclusions);
  if (stats.availableCount <= 0) {
    return {
      success: false,
      numbers: [],
      error: 'All numbers within this range are currently excluded. Clear some exclusions to draw.',
    };
  }

  if (!allowDuplicates && count > stats.availableCount) {
    return {
      success: false,
      numbers: [],
      error: `Cannot pick ${count} unique numbers: only ${stats.availableCount} numbers remain available in this range.`,
    };
  }

  const results: number[] = [];

  // Small to medium pool optimization: collect valid pool
  if (totalInRange <= 100000) {
    const validPool: number[] = [];
    for (let i = low; i <= high; i++) {
      if (!isNumberExcluded(i, exclusions)) {
        validPool.push(i);
      }
    }

    if (validPool.length === 0) {
      return { success: false, numbers: [], error: 'No available numbers remaining.' };
    }

    if (!allowDuplicates) {
      // Fisher-Yates shuffle sample
      const poolCopy = [...validPool];
      for (let i = 0; i < count; i++) {
        const randIdx = getCryptoRandomInt(i, poolCopy.length - 1);
        const temp = poolCopy[i];
        poolCopy[i] = poolCopy[randIdx];
        poolCopy[randIdx] = temp;
        results.push(poolCopy[i]);
      }
    } else {
      // With replacement
      for (let i = 0; i < count; i++) {
        const randIdx = getCryptoRandomInt(0, validPool.length - 1);
        results.push(validPool[randIdx]);
      }
    }
  } else {
    // Large pool rejection sampling
    const pickedSet = new Set<number>();
    let safetyCounter = 0;

    while (results.length < count && safetyCounter < 100000) {
      safetyCounter++;
      const candidate = getCryptoRandomInt(low, high);
      if (isNumberExcluded(candidate, exclusions)) {
        continue;
      }
      if (!allowDuplicates && pickedSet.has(candidate)) {
        continue;
      }
      if (!allowDuplicates) {
        pickedSet.add(candidate);
      }
      results.push(candidate);
    }

    if (results.length < count) {
      return {
        success: false,
        numbers: results,
        error: 'Timeout while picking numbers due to dense exclusion boundaries.',
      };
    }
  }

  if (autoSort === 'asc') {
    results.sort((a, b) => a - b);
  } else if (autoSort === 'desc') {
    results.sort((a, b) => b - a);
  }

  return {
    success: true,
    numbers: results,
  };
}

/**
 * Parses user input string (e.g., "7, 13, 20-25, 42") into exclusion items
 */
export function parseExclusionInput(input: string): ExclusionItem[] {
  const parts = input.split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
  const items: ExclusionItem[] = [];

  for (const part of parts) {
    if (part.includes('-') && !part.startsWith('-') || part.includes('..')) {
      const separator = part.includes('..') ? '..' : '-';
      const [startStr, endStr] = part.split(separator);
      const start = parseInt(startStr, 10);
      const end = parseInt(endStr, 10);
      if (!isNaN(start) && !isNaN(end)) {
        const low = Math.min(start, end);
        const high = Math.max(start, end);
        items.push({
          id: `range-${low}-${high}-${Date.now()}-${Math.random()}`,
          type: 'range',
          start: low,
          end: high,
          label: `${low} – ${high}`,
          createdAt: Date.now(),
        });
      }
    } else {
      const num = parseInt(part, 10);
      if (!isNaN(num)) {
        items.push({
          id: `single-${num}-${Date.now()}-${Math.random()}`,
          type: 'single',
          value: num,
          label: `${num}`,
          createdAt: Date.now(),
        });
      }
    }
  }

  return items;
}
