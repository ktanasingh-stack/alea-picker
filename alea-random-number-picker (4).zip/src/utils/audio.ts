// Web Audio API Sound Synthesizer for realistic rolling sounds, mechanical clicks, and celebration chimes

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private noiseBuffer: AudioBuffer | null = null;
  private activeRollingSource: AudioBufferSourceNode | null = null;
  private activeRollingGain: GainNode | null = null;

  constructor() {
    const saved = localStorage.getItem('alea_sound_muted');
    if (saved !== null) {
      this.isMuted = saved === 'true';
    }
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.createNoiseBuffer();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  // Pre-generate 2 seconds of pink/white noise for natural rolling friction texture
  private createNoiseBuffer() {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      // Pink noise filter algorithm
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
    this.noiseBuffer = buffer;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    localStorage.setItem('alea_sound_muted', String(muted));
    if (muted) {
      this.stopRollingSound();
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  /**
   * Starts a continuous, rich physical rolling sound (spinning wheel / tumbling ball & cylinder)
   * The sound starts with energetic velocity and smoothly decelerates in pitch and volume.
   */
  public startRollingSound(durationMs = 2000) {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      if (!this.noiseBuffer) this.createNoiseBuffer();
      if (!this.noiseBuffer) return;

      this.stopRollingSound();

      const source = this.ctx.createBufferSource();
      source.buffer = this.noiseBuffer;
      source.loop = true;

      // Bandpass filter to sculpt the rolling ball/cylinder resonance
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(650, this.ctx.currentTime);
      filter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      // Lowpass filter for warm body resonance
      const lowpass = this.ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.setValueAtTime(1400, this.ctx.currentTime);

      const gain = this.ctx.createGain();
      const startTime = this.ctx.currentTime;
      const endTime = startTime + durationMs / 1000;

      // Gentle fade in, steady rumble, deceleration downward frequency curve, fade out
      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.linearRampToValueAtTime(0.07, startTime + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.02, endTime - 0.2);
      gain.gain.linearRampToValueAtTime(0.0001, endTime);

      // Smoothly pitch down the resonance as rotation slows
      filter.frequency.exponentialRampToValueAtTime(220, endTime);

      source.connect(filter);
      filter.connect(lowpass);
      lowpass.connect(gain);
      gain.connect(this.ctx.destination);

      source.start(startTime);
      source.stop(endTime);

      this.activeRollingSource = source;
      this.activeRollingGain = gain;
    } catch {
      // Audio error safely handled
    }
  }

  /**
   * Immediately stops active continuous rolling sound
   */
  public stopRollingSound() {
    try {
      if (this.activeRollingGain && this.ctx) {
        this.activeRollingGain.gain.cancelScheduledValues(this.ctx.currentTime);
        this.activeRollingGain.gain.setValueAtTime(0, this.ctx.currentTime);
      }
      if (this.activeRollingSource) {
        this.activeRollingSource.stop();
        this.activeRollingSource.disconnect();
        this.activeRollingSource = null;
      }
    } catch {
      // Audio stop safely handled
    }
  }

  /**
   * Tactile click / tumbling peg impact with organic micro-variations
   */
  public playTick(pitchMultiplier = 1.0) {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Mechanical wooden / click strike with subtle random pitch variance
      const variance = (Math.random() - 0.5) * 40;
      const baseFreq = 540 * pitchMultiplier + variance;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.035);

      gain.gain.setValueAtTime(0.09, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.035);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.04);
    } catch {
      // Audio error safely handled
    }
  }

  /**
   * Rich celebratory chords and resonant chime on number selected
   */
  public playWin() {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 arpeggio
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const startTime = this.ctx.currentTime + idx * 0.065;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.001, startTime);
        gain.gain.exponentialRampToValueAtTime(0.14, startTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.45);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + 0.46);
      });
    } catch {
      // Audio error safely handled
    }
  }
}

export const soundEngine = new SoundEngine();

