import { useEffect, useState, useCallback, useRef } from 'react';

export interface TrafficStats {
  liveVisitors: number;
  todayVisitors: number;
  todayPageviews: number;
  totalPageviews: number;
  totalDraws: number;
  devices: Record<string, number>;
  browsers: Record<string, number>;
  currentLiveList: Array<{
    sessionId: string;
    activeSecondsAgo: number;
    path: string;
    device: string;
    browser: string;
    referrer: string;
  }>;
  recentPageviews: Array<{
    id: string;
    timestamp: number;
    path: string;
    referrer: string;
    device: string;
    browser: string;
  }>;
  hourlyDistribution: Array<{ hour: string; views: number }>;
}

// Ensure stable session ID per browser tab
function getSessionId(): string {
  if (typeof window === 'undefined') return 'server';
  let sid = sessionStorage.getItem('alea_traffic_session_id');
  if (!sid) {
    sid = 's_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
    sessionStorage.setItem('alea_traffic_session_id', sid);
  }
  return sid;
}

// Initialize and manage Google Analytics script tag dynamically
export function initGoogleAnalytics(measurementId: string) {
  if (typeof window === 'undefined' || !measurementId.trim()) return;

  const cleanId = measurementId.trim().toUpperCase();
  if (!cleanId.startsWith('G-')) return;

  // Check if already injected
  const existingScript = document.getElementById('ga4-script');
  if (existingScript) return;

  const script = document.createElement('script');
  script.id = 'ga4-script';
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${cleanId}`;
  document.head.appendChild(script);

  const inlineScript = document.createElement('script');
  inlineScript.id = 'ga4-init';
  inlineScript.innerHTML = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${cleanId}', { send_page_view: true });
  `;
  document.head.appendChild(inlineScript);
}

// Log random draw event to server telemetry
export async function trackDrawEvent(mode: string) {
  try {
    await fetch('/api/telemetry/event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ eventType: mode }),
    });
  } catch {
    // Silent fallback
  }
}

// React Hook for live visitor tracking & stats
export function useTrafficTracker() {
  const [stats, setStats] = useState<TrafficStats>({
    liveVisitors: 1,
    todayVisitors: 1,
    todayPageviews: 1,
    totalPageviews: 124,
    totalDraws: 86,
    devices: { Desktop: 1, Mobile: 0, Tablet: 0 },
    browsers: { Chrome: 1 },
    currentLiveList: [],
    recentPageviews: [],
    hourlyDistribution: [],
  });

  const [gaId, setGaId] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('alea_ga_id') || '';
    }
    return '';
  });

  const hasSentInitialRef = useRef(false);

  // Initialize GA if saved
  useEffect(() => {
    if (gaId) {
      initGoogleAnalytics(gaId);
    }
  }, [gaId]);

  const saveGaId = (id: string) => {
    const trimmed = id.trim();
    setGaId(trimmed);
    localStorage.setItem('alea_ga_id', trimmed);
    if (trimmed) {
      initGoogleAnalytics(trimmed);
    }
  };

  const sendHeartbeat = useCallback(async (isNewPageview = false) => {
    try {
      const sessionId = getSessionId();
      const res = await fetch('/api/telemetry/heartbeat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          path: window.location.pathname || '/',
          referrer: document.referrer || '',
          isNewPageview,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setStats((prev) => ({
          ...prev,
          liveVisitors: data.liveVisitors ?? prev.liveVisitors,
          todayVisitors: data.todayVisitors ?? prev.todayVisitors,
          todayPageviews: data.todayPageviews ?? prev.todayPageviews,
          totalPageviews: data.totalPageviews ?? prev.totalPageviews,
        }));
      }
    } catch {
      // Fallback silently if offline
    }
  }, []);

  const fetchFullStats = useCallback(async () => {
    try {
      const res = await fetch('/api/telemetry/stats');
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch {
      // Silently catch
    }
  }, []);

  useEffect(() => {
    // Initial pageview heartbeat
    if (!hasSentInitialRef.current) {
      hasSentInitialRef.current = true;
      sendHeartbeat(true);
    }

    // Regular presence ping every 20 seconds
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        sendHeartbeat(false);
      }
    }, 20000);

    // Heartbeat on visibility resume
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        sendHeartbeat(false);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [sendHeartbeat]);

  return {
    stats,
    gaId,
    saveGaId,
    fetchFullStats,
    sendHeartbeat,
  };
}
