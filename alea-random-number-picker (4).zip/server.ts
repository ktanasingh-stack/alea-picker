import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// In-Memory Live Visitor & Traffic Store
interface ActiveVisitor {
  sessionId: string;
  firstSeen: number;
  lastSeen: number;
  path: string;
  referrer: string;
  device: string;
  browser: string;
  ipHash: string;
}

interface PageviewRecord {
  id: string;
  timestamp: number;
  path: string;
  referrer: string;
  device: string;
  browser: string;
}

const activeVisitors = new Map<string, ActiveVisitor>();
const recentPageviews: PageviewRecord[] = [];
let totalAllTimePageviews = 124; // Baseline seed
let totalAllTimeDraws = 86;

// Helper to determine date key YYYY-MM-DD
function getTodayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

// Map of date string -> Set of unique sessionIds
const dailyUniqueVisitors = new Map<string, Set<string>>();
const dailyPageviews = new Map<string, number>();

// Clean up stale sessions older than 45 seconds
function cleanupStaleVisitors() {
  const now = Date.now();
  const threshold = 45 * 1000;
  for (const [id, visitor] of activeVisitors.entries()) {
    if (now - visitor.lastSeen > threshold) {
      activeVisitors.delete(id);
    }
  }
}

// Run cleanup every 15 seconds
setInterval(cleanupStaleVisitors, 15000);

// Simple device parser from User-Agent
function parseDeviceInfo(userAgent = ''): { device: string; browser: string } {
  let device = 'Desktop';
  if (/mobile/i.test(userAgent)) device = 'Mobile';
  else if (/tablet|ipad/i.test(userAgent)) device = 'Tablet';

  let browser = 'Chrome';
  if (/firefox/i.test(userAgent)) browser = 'Firefox';
  else if (/safari/i.test(userAgent) && !/chrome/i.test(userAgent)) browser = 'Safari';
  else if (/edg/i.test(userAgent)) browser = 'Edge';
  else if (/opera|opr/i.test(userAgent)) browser = 'Opera';

  return { device, browser };
}

// -------------------------------------------------------------
// TELEMETRY API ROUTES
// -------------------------------------------------------------

// Heartbeat endpoint: called on initial load & every 20 seconds while active
app.post('/api/telemetry/heartbeat', (req: Request, res: Response) => {
  try {
    const { sessionId, path: currentPath = '/', referrer = '', isNewPageview = false } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: 'Missing sessionId' });
    }

    const now = Date.now();
    const today = getTodayKey();
    const ua = req.headers['user-agent'] || '';
    const ip = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
    const ipHash = crypto.createHash('sha256').update(ip).digest('hex').slice(0, 12);
    const { device, browser } = parseDeviceInfo(ua);

    // Track active session
    const existing = activeVisitors.get(sessionId);
    if (existing) {
      existing.lastSeen = now;
      existing.path = currentPath;
    } else {
      activeVisitors.set(sessionId, {
        sessionId,
        firstSeen: now,
        lastSeen: now,
        path: currentPath,
        referrer: referrer || 'Direct',
        device,
        browser,
        ipHash,
      });
    }

    // Daily unique tracking
    if (!dailyUniqueVisitors.has(today)) {
      dailyUniqueVisitors.set(today, new Set());
    }
    dailyUniqueVisitors.get(today)!.add(sessionId);

    // Pageview increment
    if (isNewPageview) {
      totalAllTimePageviews++;
      const currentTodayPv = dailyPageviews.get(today) || 0;
      dailyPageviews.set(today, currentTodayPv + 1);

      recentPageviews.unshift({
        id: `pv-${Date.now()}-${Math.random()}`,
        timestamp: now,
        path: currentPath,
        referrer: referrer || 'Direct',
        device,
        browser,
      });

      if (recentPageviews.length > 50) {
        recentPageviews.pop();
      }
    }

    cleanupStaleVisitors();

    const liveCount = Math.max(1, activeVisitors.size);
    const todayVisitorsCount = dailyUniqueVisitors.get(today)?.size || 1;
    const todayPageviewsCount = dailyPageviews.get(today) || 1;

    res.json({
      success: true,
      liveVisitors: liveCount,
      todayVisitors: todayVisitorsCount,
      todayPageviews: todayPageviewsCount,
      totalPageviews: totalAllTimePageviews,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to process heartbeat' });
  }
});

// Event endpoint: track random draws and user actions
app.post('/api/telemetry/event', (req: Request, res: Response) => {
  try {
    const { eventType } = req.body;
    if (eventType === 'draw' || eventType === 'spin') {
      totalAllTimeDraws++;
    }
    res.json({ success: true, totalDraws: totalAllTimeDraws });
  } catch {
    res.status(500).json({ error: 'Failed to log event' });
  }
});

// Stats endpoint: detailed analytics dashboard query
app.get('/api/telemetry/stats', (_req: Request, res: Response) => {
  try {
    cleanupStaleVisitors();
    const today = getTodayKey();
    const liveCount = Math.max(1, activeVisitors.size);
    const todayVisitors = dailyUniqueVisitors.get(today)?.size || 1;
    const todayPageviews = dailyPageviews.get(today) || 1;

    // Device breakdown
    const devices: Record<string, number> = { Desktop: 0, Mobile: 0, Tablet: 0 };
    const browsers: Record<string, number> = {};

    for (const v of activeVisitors.values()) {
      devices[v.device] = (devices[v.device] || 0) + 1;
      browsers[v.browser] = (browsers[v.browser] || 0) + 1;
    }

    // Active visitor list for live monitor
    const currentLiveList = Array.from(activeVisitors.values()).map((v) => ({
      sessionId: v.sessionId.slice(0, 8),
      activeSecondsAgo: Math.max(0, Math.round((Date.now() - v.lastSeen) / 1000)),
      path: v.path,
      device: v.device,
      browser: v.browser,
      referrer: v.referrer,
    }));

    // Simulated 24-hour distribution curve
    const hours = Array.from({ length: 24 }, (_, i) => {
      const hStr = `${i.toString().padStart(2, '0')}:00`;
      // baseline distribution shape
      const weight = Math.sin(((i - 6) / 24) * Math.PI) * 0.5 + 0.5;
      const count = Math.max(1, Math.round(weight * (todayPageviews + 12)));
      return { hour: hStr, views: count };
    });

    res.json({
      liveVisitors: liveCount,
      todayVisitors,
      todayPageviews,
      totalPageviews: totalAllTimePageviews,
      totalDraws: totalAllTimeDraws,
      devices,
      browsers,
      currentLiveList,
      recentPageviews: recentPageviews.slice(0, 15),
      hourlyDistribution: hours,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve stats' });
  }
});

// -------------------------------------------------------------
// VITE INTEGRATION / STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Alea server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
